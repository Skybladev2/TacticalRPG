﻿String.prototype.endsWith = function (suffix) {
    return this.indexOf(suffix, this.length - suffix.length) !== -1;
};

$(document).ready(function () {
    $('a[data-mainmenulink]').each(function () {
        var attr = $(this).attr("data-mainmenulink");
        if (window.location.pathname.endsWith(attr)) {
            var element = $(this).find('.smallInnerTileLink');
            element.removeAttr("class");
            element.addClass('selectedSmallInnerTileLink');
        }
    });
});